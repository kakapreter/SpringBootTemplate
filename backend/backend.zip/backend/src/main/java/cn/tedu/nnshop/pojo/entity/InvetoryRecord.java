package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("invetory_record")
public class InvetoryRecord implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "record_id", type = IdType.ASSIGN_ID)
    private Integer recordId;

    @TableField("admin_id")
    private Integer adminId;

    @TableField("product_id")
    private Integer productId;

    @TableField("operate_type")
    private String operateType;

    @TableField("operate_count")
    private Integer operateCount;

    @TableField("operate_time")
    private Date operateTime;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("updte_time")
    private LocalDateTime updteTime;


}

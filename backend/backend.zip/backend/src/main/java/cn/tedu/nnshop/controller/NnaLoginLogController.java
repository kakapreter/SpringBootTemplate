package cn.tedu.nnshop.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 管理员登录日志 前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@RestController
@RequestMapping("/nna-login-log")
public class NnaLoginLogController {

}

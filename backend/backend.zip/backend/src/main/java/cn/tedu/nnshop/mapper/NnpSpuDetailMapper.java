package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.NnpSpuDetail;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * SPU详情 Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */

public interface NnpSpuDetailMapper extends BaseMapper<NnpSpuDetail> , MPJBaseMapper<NnpSpuDetail> {

}

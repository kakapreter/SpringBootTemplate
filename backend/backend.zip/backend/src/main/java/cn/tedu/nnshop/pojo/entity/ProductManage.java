package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("product_manage")
public class ProductManage implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "product_manage_id", type = IdType.ASSIGN_ID)
    private Integer productManageId;

    @TableField("admin_id")
    private Integer adminId;

    @TableField("product_id")
    private Integer productId;

    @TableField("operate_type")
    private String operateType;

    @TableField("operate_time")
    private LocalDateTime operateTime;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;


}

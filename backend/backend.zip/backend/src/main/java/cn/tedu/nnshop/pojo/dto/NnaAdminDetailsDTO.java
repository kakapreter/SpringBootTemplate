package cn.tedu.nnshop.pojo.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@TableName("nna_admin")
public class NnaAdminDetailsDTO {

    @TableField("name")
    private String name;

    @TableField("pwd")
    private String pwd;

    @TableField("nickname")
    private String nickname;

    @TableField("email")
    private String email;

    @TableField("phone")
    private String phone;
}

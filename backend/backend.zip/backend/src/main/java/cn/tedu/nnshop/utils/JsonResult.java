package cn.tedu.nnshop.utils;


import cn.tedu.nnshop.service.exception.ServiceCode;
import cn.tedu.nnshop.service.exception.ServiceException;
import lombok.Data;

import java.io.Serializable;

@Data
public class JsonResult<T> implements Serializable {
    /**
     * 状态码, 20000表示成功
     */
    private Integer code;
    /**
     * 操作"失败"时描述的文本, 正确的时候可以返回null
     */
    private String message;
    /**
     * 操作"成功"时响应的数据
     */
    private T data;

    /**
     * 操作成功 返回数据的方法
     * @param data
     * @param <T>
     * @return
     */
    public static <T> JsonResult<T> ok(T data) {
        JsonResult<T> jsonResult = new JsonResult<>();
        jsonResult.setCode(ServiceCode.OK.getValue()); // 操作正常 20000
        jsonResult.setData(data); // 响应的数据
        jsonResult.setMessage("OK");
        return jsonResult;
    }

    /**
     * 针对增删改等业务的数据返回
     * @return
     */
    public static JsonResult<Void> ok() {
        return ok(null);
    }

    public static JsonResult<Void> fail(ServiceCode serviceCode, String message) {
        JsonResult<Void> jsonResult = new JsonResult<>();
        jsonResult.setMessage(message);
        jsonResult.setCode(serviceCode.getValue());
        return jsonResult;
    }
    public static JsonResult<Void> fail(ServiceException e) {
        return fail(e.getServiceCode(), e.getMessage());
    }
}


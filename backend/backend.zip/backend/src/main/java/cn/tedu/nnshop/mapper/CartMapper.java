package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.Cart;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
public interface CartMapper extends BaseMapper<Cart> {

}

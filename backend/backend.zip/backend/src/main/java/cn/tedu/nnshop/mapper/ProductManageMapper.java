package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.ProductManage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
public interface ProductManageMapper extends BaseMapper<ProductManage> , MPJBaseMapper<ProductManage> {

}

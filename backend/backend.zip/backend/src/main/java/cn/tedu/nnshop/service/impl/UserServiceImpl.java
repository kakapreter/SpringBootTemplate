package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.User;
import cn.tedu.nnshop.mapper.UserMapper;
import cn.tedu.nnshop.service.UserService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class UserServiceImpl extends MPJBaseServiceImpl<UserMapper, User> implements UserService {

}

package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.NnaLoginLog;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 管理员登录日志 Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */

public interface NnaLoginLogMapper extends BaseMapper<NnaLoginLog> , MPJBaseMapper<NnaLoginLog> {

}

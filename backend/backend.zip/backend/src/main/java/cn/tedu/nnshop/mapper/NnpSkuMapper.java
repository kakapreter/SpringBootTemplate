package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.NnpSku;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;

/**
 * <p>
 * SKU（Stock Keeping Unit） Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
public interface NnpSkuMapper extends BaseMapper<NnpSku> , MPJBaseMapper<NnpSku> {

}

package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * SPU（Standard Product Unit）
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("nnp_spu")
public class NnpSpu implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * SPU名称
     */
    @TableField("name")
    private String name;

    /**
     * SPU编号
     */
    @TableField("type_number")
    private String typeNumber;

    /**
     * 标题
     */
    @TableField("title")
    private String title;

    /**
     * SPU简介
     */
    @TableField("description")
    private String description;

    /**
     * 价格（显示在列表中）
     */
    @TableField("list_price")
    private BigDecimal listPrice;

    /**
     * 当前库存（冗余）
     */
    @TableField("stock")
    private Integer stock;

    /**
     * 库存预警阈值（冗余）
     */
    @TableField("stock_threshold")
    private Integer stockThreshold;

    /**
     * 计件单位
     */
    @TableField("unit")
    private String unit;

    /**
     * 品牌id
     */
    @TableField("brand_id")
    private Long brandId;

    /**
     * 品牌名称（冗余）
     */
    @TableField("brand_name")
    private String brandName;

    /**
     * 类别id
     */
    @TableField("category_id")
    private Long categoryId;

    /**
     * 类别名称（冗余）
     */
    @TableField("category_name")
    private String categoryName;

    /**
     * 属性模版id
     */
    @TableField("attribute_template_id")
    private Long attributeTemplateId;

    /**
     * 相册id
     */
    @TableField("album_id")
    private Long albumId;

    /**
     * 组图URLs，使用JSON数组表示
     */
    @TableField("pictures")
    private String pictures;

    /**
     * 关键词列表，各关键词使用英文的逗号分隔
     */
    @TableField("keywords")
    private String keywords;

    /**
     * 标签列表，各标签使用英文的逗号分隔，原则上最多3个
     */
    @TableField("tags")
    private String tags;

    /**
     * 销量（冗余）
     */
    @TableField("sales")
    private Integer sales;

    /**
     * 买家评论数量总和（冗余）
     */
    @TableField("comment_count")
    private Integer commentCount;

    /**
     * 买家好评数量总和（冗余）
     */
    @TableField("positive_comment_count")
    private Integer positiveCommentCount;

    /**
     * 排序序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 是否标记为删除，1=已删除，0=未删除
     */
    @TableField("is_deleted")
    private Integer isDeleted;

    /**
     * 是否上架（发布），1=已上架，0=未上架（下架）
     */
    @TableField("is_published")
    private Integer isPublished;

    /**
     * 是否新品，1=新品，0=非新品
     */
    @TableField("is_new_arrival")
    private Integer isNewArrival;

    /**
     * 是否推荐，1=推荐，0=不推荐
     */
    @TableField("is_recommend")
    private Integer isRecommend;

    /**
     * 是否已审核，1=已审核，0=未审核
     */
    @TableField("is_checked")
    private Integer isChecked;

    /**
     * 审核人（冗余）
     */
    @TableField("check_user")
    private String checkUser;

    /**
     * 审核通过时间（冗余）
     */
    @TableField("gmt_check")
    private Date gmtCheck;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

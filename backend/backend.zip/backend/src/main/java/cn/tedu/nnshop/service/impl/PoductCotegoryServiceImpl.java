package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.PoductCotegory;
import cn.tedu.nnshop.mapper.PoductCotegoryMapper;
import cn.tedu.nnshop.service.PoductCotegoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@Service
public class PoductCotegoryServiceImpl extends ServiceImpl<PoductCotegoryMapper, PoductCotegory> implements PoductCotegoryService {

}

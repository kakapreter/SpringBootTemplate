package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.CartItem;
import cn.tedu.nnshop.mapper.CartItemMapper;
import cn.tedu.nnshop.service.CartItemService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class CartItemServiceImpl extends ServiceImpl<CartItemMapper, CartItem> implements CartItemService {

}

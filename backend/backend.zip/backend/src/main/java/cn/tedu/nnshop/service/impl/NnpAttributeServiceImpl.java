package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.NnpAttribute;
import cn.tedu.nnshop.mapper.NnpAttributeMapper;
import cn.tedu.nnshop.service.NnpAttributeService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 属性 服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class NnpAttributeServiceImpl extends MPJBaseServiceImpl<NnpAttributeMapper, NnpAttribute> implements NnpAttributeService {

}

package cn.tedu.nnshop.service;

import cn.tedu.nnshop.pojo.entity.User;
import com.baomidou.mybatisplus.extension.service.IService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import com.github.yulichang.extension.mapping.base.MPJDeepService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
public interface UserService extends MPJDeepService<User> {

}

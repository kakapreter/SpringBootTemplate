package cn.tedu.nnshop.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@RestController
@RequestMapping("/product-image")
public class ProductImageController {

}

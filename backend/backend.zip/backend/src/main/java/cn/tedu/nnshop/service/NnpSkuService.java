package cn.tedu.nnshop.service;

import cn.tedu.nnshop.pojo.entity.NnpSku;
import com.baomidou.mybatisplus.extension.service.IService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import com.github.yulichang.extension.mapping.base.MPJDeepService;

/**
 * <p>
 * SKU（Stock Keeping Unit） 服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
public interface NnpSkuService extends MPJDeepService<NnpSku> {

}

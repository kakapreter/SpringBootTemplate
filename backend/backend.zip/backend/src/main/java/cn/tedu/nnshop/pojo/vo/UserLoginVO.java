package cn.tedu.nnshop.pojo.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("user")
public class UserLoginVO {
    @TableField("name")
    private String name;

    @TableField("pwd")
    private String pwd;
}

package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 类别
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("nnp_category")
public class NnpCategory implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 类别名称
     */
    @TableField("name")
    private String name;

    /**
     * 父级类别id，如果无父级，则为0
     */
    @TableField("parent_id")
    private Long parentId;

    /**
     * 深度，最顶级类别的深度为1，次级为2，以此类推
     */
    @TableField("depth")
    private Integer depth;

    /**
     * 关键词列表，各关键词使用英文的逗号分隔
     */
    @TableField("keywords")
    private String keywords;

    /**
     * 排序序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 图标图片的URL
     */
    @TableField("icon")
    private String icon;

    /**
     * 是否启用，1=启用，0=未启用
     */
    @TableField("enable")
    private Integer enable;

    /**
     * 是否为父级（是否包含子级），1=是父级，0=不是父级
     */
    @TableField("is_parent")
    private Integer isParent;

    /**
     * 是否显示在导航栏中，1=启用，0=未启用
     */
    @TableField("is_display")
    private Integer isDisplay;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

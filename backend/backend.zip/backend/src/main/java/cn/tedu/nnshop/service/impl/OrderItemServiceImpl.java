package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.OrderItem;
import cn.tedu.nnshop.mapper.OrderItemMapper;
import cn.tedu.nnshop.service.OrderItemService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class OrderItemServiceImpl extends MPJBaseServiceImpl<OrderItemMapper, OrderItem> implements OrderItemService {

}

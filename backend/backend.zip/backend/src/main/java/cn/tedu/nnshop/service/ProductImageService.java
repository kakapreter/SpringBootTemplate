package cn.tedu.nnshop.service;

import cn.tedu.nnshop.pojo.entity.ProductImage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
public interface ProductImageService extends IService<ProductImage> {

}

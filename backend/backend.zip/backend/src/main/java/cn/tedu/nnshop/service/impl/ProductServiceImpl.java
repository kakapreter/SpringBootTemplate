package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.Product;
import cn.tedu.nnshop.mapper.ProductMapper;
import cn.tedu.nnshop.service.ProductService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class ProductServiceImpl extends MPJBaseServiceImpl<ProductMapper, Product> implements ProductService {

}

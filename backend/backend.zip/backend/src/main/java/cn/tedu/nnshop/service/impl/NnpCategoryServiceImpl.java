package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.NnpCategory;
import cn.tedu.nnshop.mapper.NnpCategoryMapper;
import cn.tedu.nnshop.service.NnpCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 类别 服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class NnpCategoryServiceImpl extends MPJBaseServiceImpl<NnpCategoryMapper, NnpCategory> implements NnpCategoryService {

}

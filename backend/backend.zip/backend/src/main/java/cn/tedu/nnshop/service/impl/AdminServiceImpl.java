package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.Admin;
import cn.tedu.nnshop.mapper.AdminMapper;
import cn.tedu.nnshop.service.AdminService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@Service
public class AdminServiceImpl extends ServiceImpl<AdminMapper, Admin> implements AdminService {

}

package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.Admin;
import cn.tedu.nnshop.mapper.AdminMapper;
import cn.tedu.nnshop.service.AdminService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class AdminServiceImpl extends MPJBaseServiceImpl<AdminMapper, Admin> implements AdminService {

}

package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * SKU数据
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("nnp_sku_specification")
public class NnpSkuSpecification implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * SKU id
     */
    @TableField("sku_id")
    private Long skuId;

    /**
     * 属性id
     */
    @TableField("attribute_id")
    private Long attributeId;

    /**
     * 属性名称
     */
    @TableField("attribute_name")
    private String attributeName;

    /**
     * 属性值
     */
    @TableField("attribute_value")
    private String attributeValue;

    /**
     * 自动补充的计量单位
     */
    @TableField("unit")
    private String unit;

    /**
     * 排序序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.ProductManage;
import cn.tedu.nnshop.mapper.ProductManageMapper;
import cn.tedu.nnshop.service.ProductManageService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class ProductManageServiceImpl extends MPJBaseServiceImpl<ProductManageMapper, ProductManage> implements ProductManageService {

}

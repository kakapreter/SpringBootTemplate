package cn.tedu.nnshop.controller;

import cn.tedu.nnshop.pojo.entity.Product;
import cn.tedu.nnshop.service.ProductService;
import cn.tedu.nnshop.utils.JsonResult;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@RestController
@RequestMapping("/api/product")
@CrossOrigin
@Tag(name = "商品管理模块")
public class ProductController {
    @Autowired
    private ProductService productService;

    @Operation(summary = "查看所有商品")
    @GetMapping("/data/list")
    public JsonResult<List<Product>> listProduct(){
        return JsonResult.ok(productService.list(null));
    }

}

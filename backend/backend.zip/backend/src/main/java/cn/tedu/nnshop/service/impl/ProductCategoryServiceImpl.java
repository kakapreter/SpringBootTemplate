package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.ProductCategory;
import cn.tedu.nnshop.mapper.ProductCategoryMapper;
import cn.tedu.nnshop.service.ProductCategoryService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class ProductCategoryServiceImpl extends MPJBaseServiceImpl<ProductCategoryMapper, ProductCategory> implements ProductCategoryService {

}

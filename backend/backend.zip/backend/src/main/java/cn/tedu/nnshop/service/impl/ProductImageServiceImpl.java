package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.ProductImage;
import cn.tedu.nnshop.mapper.ProductImageMapper;
import cn.tedu.nnshop.service.ProductImageService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class ProductImageServiceImpl extends ServiceImpl<ProductImageMapper, ProductImage> implements ProductImageService {

}

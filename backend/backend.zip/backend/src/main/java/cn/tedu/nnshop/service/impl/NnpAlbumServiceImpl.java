package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.NnpAlbum;
import cn.tedu.nnshop.mapper.NnpAlbumMapper;
import cn.tedu.nnshop.service.NnpAlbumService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 相册 服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class NnpAlbumServiceImpl extends MPJBaseServiceImpl<NnpAlbumMapper, NnpAlbum> implements NnpAlbumService {

}

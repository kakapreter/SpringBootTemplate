package cn.tedu.nnshop.controller;

import cn.tedu.nnshop.pojo.dto.NnaAdminDetailsDTO;
import cn.tedu.nnshop.pojo.dto.UserLoginDTO;
import cn.tedu.nnshop.pojo.dto.UserRegisterDTO;
import cn.tedu.nnshop.pojo.entity.User;
import cn.tedu.nnshop.service.UserService;
import cn.tedu.nnshop.utils.JsonResult;
import cn.tedu.nnshop.utils.JwtUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@Slf4j
//跨域配置
@CrossOrigin
@RestController
@RequestMapping("/api/user")
@Api(value = "测试controller",tags = {"普通用户接口"})
public class UserController {
    @Autowired
    private UserService userService;

    //insert
    @ApiOperation("注册用户")
    @PutMapping("/add")
    public JsonResult<Void> addUser(@RequestBody UserRegisterDTO user){
        User registerUser = new User();
        registerUser.setName(user.getName());
        registerUser.setPwd(user.getPwd());
        userService.save(registerUser);
        return JsonResult.ok();
    }

    //delete
    @ApiOperation("根据id删除用户")
    @DeleteMapping("/del/{id}")
    public JsonResult<Void> deleteUserById(@PathVariable(name = "id") Integer id){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getId,id);
        userService.removeById(id);
        return JsonResult.ok();
    }

    //update
    @ApiOperation("根据id修改用户信息")
    @PutMapping("/upd/{id}")
    public JsonResult<Void> updateDetailsById(@RequestBody NnaAdminDetailsDTO user, @PathVariable(name = "id") Integer id){
        LambdaUpdateWrapper<User> wrapper = new LambdaUpdateWrapper<>();
        wrapper.set(User::getName,user.getName())
                .set(User::getPwd,user.getPwd())
                .eq(User::getId , id);
        userService.update(wrapper);
        return JsonResult.ok();
    }

    //select
    @ApiOperation("用户登录")
    @PostMapping("/login")
    public JsonResult<Map<String,String>> loginByUsername(@RequestBody UserLoginDTO user){
        Map<String,String> tokenResult = new HashMap<>();
        tokenResult.put("token",JwtUtils.sign(user.getName()));
        tokenResult.put("username",user.getName());
        tokenResult.put("password",user.getPwd());
        return JsonResult.ok(tokenResult);
    }

    @ApiOperation("返回用户名与头像")
    @GetMapping("/info")
    public JsonResult<Map<String, String>> info(String token){
        String username = JwtUtils.getUsername(token);
        String avatarUrl = "https://upen.caup.net/ai_pics_mj/202303/1677952366325269.jpg";
        Map<String,String> baseInfo = new HashMap<>();
        baseInfo.put("name",username);
        baseInfo.put("avatar",avatarUrl);
        return JsonResult.ok(baseInfo);
    }

    @ApiOperation("查询所有用户信息")
    @GetMapping("/list")
    public JsonResult<List<User>> listUser(){
        return JsonResult.ok(userService.list(null));
    }

    @ApiOperation("分页查询所有用户信息")
    @GetMapping("/list/{current}/{size}")
    public JsonResult<Page<User>> listUserById(@PathVariable(name = "current") Long current, @PathVariable(name = "size")Long size) {
        return JsonResult.ok(userService.page(new Page<>(current, size)));
    }


}

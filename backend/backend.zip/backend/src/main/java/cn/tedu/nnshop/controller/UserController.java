package cn.tedu.nnshop.controller;

import cn.tedu.nnshop.pojo.dto.UserDetailsDTO;
import cn.tedu.nnshop.pojo.dto.UserLoginDTO;
import cn.tedu.nnshop.pojo.entity.User;
import cn.tedu.nnshop.pojo.vo.UserDetailsVO;
import cn.tedu.nnshop.service.UserService;
import cn.tedu.nnshop.utils.JsonResult;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.time.LocalDateTime;
import java.util.List;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@Slf4j
//跨域配置
@CrossOrigin
@RestController
@RequestMapping("/api/user")
@Tag(name = "普通用户管理模块")
public class UserController {
    @Autowired
    private UserService userService;

    //insert
    @Operation(summary = "注册用户操作")
    @PutMapping("/add")
    public JsonResult<Void> addUser(@RequestBody UserDetailsDTO user){
        User registerUser = new User();
        registerUser.setPhone(user.getPhone());
        registerUser.setName(user.getName());
        registerUser.setPwd(user.getPwd());
        registerUser.setEmail(user.getEmail());
        registerUser.setAddress(user.getAddress());
        registerUser.setCreateTime(LocalDateTime.now());
        registerUser.setUpdateTime(LocalDateTime.now());
        userService.save(registerUser);
        return JsonResult.ok();
    }

    //delete
    @Operation(summary = "根据id删除操作")
    @DeleteMapping("/delete/{id}")
    public JsonResult<Void> deleteUserById(@PathVariable(name = "id") Integer id){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getUserId,id);
        userService.removeById(id);
        return JsonResult.ok();
    }

    //update
    @Operation(summary = "根据id修改详细信息操作")
    @PutMapping("/update/{id}")
    public JsonResult<Void> updateDetailsById(@RequestBody UserDetailsDTO user, @PathVariable(name = "id") Integer id){
        LambdaUpdateWrapper<User> wrapper = new LambdaUpdateWrapper<>();
        wrapper.set(User::getName,user.getName())
                .set(User::getPhone,user.getPhone())
                .set(User::getEmail,user.getEmail())
                .set(User::getPwd,user.getPwd())
                .set(User::getAddress,user.getAddress())
                .eq(User::getUserId , id);
        return JsonResult.ok();
    }

    //select
    @Operation(summary = "登录操作")
    @PostMapping("/login")
    public JsonResult<User> loginByUsername(@RequestBody UserLoginDTO user){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getName,user.getName());
        wrapper.eq(User::getPwd,user.getPwd());
        User loginUser = userService.getOne(wrapper);
        return JsonResult.ok(loginUser);
    }

    @Operation(summary = "查询所有用户信息操作")
    @GetMapping("/list")
    public JsonResult<List<User>> listUser(){
        return JsonResult.ok(userService.list(null));
    }

    @Operation(summary = "根据id查询用户详细信息操作")
    @GetMapping("/list/{id}")
    public JsonResult<UserDetailsVO> listUserById(@PathVariable(name = "id") Integer id){
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getUserId,id);
        User userDetails = userService.getOne(wrapper);
        UserDetailsVO userLoginVO = new UserDetailsVO();
        userLoginVO.setName(userDetails.getName());
        userLoginVO.setPwd(userDetails.getPwd());
        userLoginVO.setAddress(userDetails.getAddress());
        userLoginVO.setEmail(userDetails.getEmail());
        userLoginVO.setPhone(userDetails.getPhone());
        return JsonResult.ok(userLoginVO);
    }

    @Operation(summary = "分页查询用户详细信息操作")
    @GetMapping("/list/{current}/{size}")
    public JsonResult<Page<User>> listUserById(@PathVariable(name = "current") Long current, @PathVariable(name = "size")Long size) {
        return JsonResult.ok(userService.page(new Page<>(current, size)));
    }
}

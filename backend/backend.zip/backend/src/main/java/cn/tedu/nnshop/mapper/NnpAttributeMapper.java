package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.NnpAttribute;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;

/**
 * <p>
 * 属性 Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
public interface NnpAttributeMapper extends BaseMapper<NnpAttribute>, MPJBaseMapper<NnpAttribute> {

}

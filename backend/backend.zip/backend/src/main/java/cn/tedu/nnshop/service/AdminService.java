package cn.tedu.nnshop.service;

import cn.tedu.nnshop.pojo.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
public interface AdminService extends IService<Admin> {

}

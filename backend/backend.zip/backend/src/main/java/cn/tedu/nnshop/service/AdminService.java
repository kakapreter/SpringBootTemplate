package cn.tedu.nnshop.service;

import cn.tedu.nnshop.pojo.entity.Admin;
import com.baomidou.mybatisplus.extension.service.IService;
import com.github.yulichang.extension.mapping.base.MPJDeepService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
public interface AdminService extends MPJDeepService<Admin> {

}

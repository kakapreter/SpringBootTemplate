package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.NnaRole;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 角色 Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */

public interface NnaRoleMapper extends BaseMapper<NnaRole> , MPJBaseMapper<NnaRole> {

}

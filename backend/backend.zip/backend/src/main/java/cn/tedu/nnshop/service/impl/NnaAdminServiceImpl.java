package cn.tedu.nnshop.service.impl;

import cn.hutool.crypto.SecureUtil;
import cn.tedu.nnshop.exception.AppException;
import cn.tedu.nnshop.exception.AppExceptionCodeMsg;
import cn.tedu.nnshop.pojo.dto.AdminDetailsDTO;
import cn.tedu.nnshop.pojo.dto.AdminLoginDTO;
import cn.tedu.nnshop.pojo.dto.AdminRegisterDTO;
import cn.tedu.nnshop.pojo.entity.NnaAdmin;
import cn.tedu.nnshop.mapper.NnaAdminMapper;
import cn.tedu.nnshop.pojo.vo.NnaAdminDetailsVO;
import cn.tedu.nnshop.service.NnaAdminService;
import cn.tedu.nnshop.utils.JwtUtils;
import cn.tedu.nnshop.utils.Validator;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.yulichang.base.MPJBaseServiceImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 *
 *
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
@Slf4j
public class NnaAdminServiceImpl extends MPJBaseServiceImpl<NnaAdminMapper, NnaAdmin> implements NnaAdminService {
    @Autowired
    private Validator emailValidator;

    @Override
    public boolean addAdmin(AdminRegisterDTO admin) {
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getName,SecureUtil.md5(admin.getPwd()));
        NnaAdmin existAdmin = getOne(wrapper);
        if (existAdmin != null){
            throw new AppException(AppExceptionCodeMsg.ERR_EXISTS);
        }
        NnaAdmin registerAdmin = new NnaAdmin();
        registerAdmin.setName(admin.getName());
        registerAdmin.setPwd(SecureUtil.md5(admin.getPwd()));//对密码进行加密
        registerAdmin.setNickname(admin.getNickname());
        registerAdmin.setEmail(admin.getEmail());
        registerAdmin.setPhone(admin.getPhone());
        registerAdmin.setUpdateTime(new Date());
        registerAdmin.setGmtCreate(new Date());
        return save(registerAdmin);
    }

    @Override
    public boolean deleteAdminById(Integer id) {
        return removeById(id);
    }

    @Override
    public boolean updateUserDetailsById(Integer id, AdminDetailsDTO adminDetailsDTO) {
        if (!emailValidator.validatePhone(adminDetailsDTO.getPhone())){
            throw new AppException(AppExceptionCodeMsg.ERR_UPDATE_FAILED);
        }
        if (!emailValidator.validateEmail(adminDetailsDTO.getEmail())){
            throw new AppException(AppExceptionCodeMsg.ERR_UPDATE_FAILED);
        }
        if(adminDetailsDTO.getPwd().length()<6 || adminDetailsDTO.getEmail().isEmpty() || adminDetailsDTO.getPhone().length() != 11){
            throw new AppException(AppExceptionCodeMsg.ERR_UPDATE_FAILED);
        }
        LambdaUpdateWrapper<NnaAdmin> wrapper = new LambdaUpdateWrapper<>();
        wrapper.set(NnaAdmin::getName,adminDetailsDTO.getName())
                .set(NnaAdmin::getPwd,SecureUtil.md5(adminDetailsDTO.getPwd()))
                .set(NnaAdmin::getEmail,adminDetailsDTO.getEmail())
                .set(NnaAdmin::getNickname,adminDetailsDTO.getNickname())
                .set(NnaAdmin::getPhone,adminDetailsDTO.getPhone())
                .eq(NnaAdmin::getId,id);
        return update(wrapper);
    }

    @Override
    public NnaAdminDetailsVO listUserDetailsById(Integer id) {
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getId,id);
        NnaAdmin admin = getOne(wrapper);
        if(admin==null){
            throw new AppException(AppExceptionCodeMsg.ERR_NOT_FOUND);
        }
        NnaAdminDetailsVO adminDetailsVO = new NnaAdminDetailsVO();
        adminDetailsVO.setId(admin.getId());
        adminDetailsVO.setPwd(admin.getPwd());
        adminDetailsVO.setPhone(admin.getPhone());
        adminDetailsVO.setName(admin.getName());
        adminDetailsVO.setEmail(admin.getEmail());
        adminDetailsVO.setNickname(admin.getNickname());
        return adminDetailsVO;
    }

    @Override
    public Page<NnaAdmin> listAllAdminPage(Long current, Long size) {
        return page(new Page<>(current, size));
    }

    @Override
    public Map<String, String> loginByUsername(AdminLoginDTO admin) {
        log.info("admin:{}",admin);
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getName,admin.getName())
                .eq(NnaAdmin::getPwd,SecureUtil.md5(admin.getPwd()));
        NnaAdmin currentAdmin = getOne(wrapper);
        log.info("currentAdmin:{}",currentAdmin);

        if (currentAdmin == null){
            throw new AppException(AppExceptionCodeMsg.ERR_UNAUTHORIZED);
        }
        Map<String,String> tokenResult = new HashMap<>();
        tokenResult.put("token", JwtUtils.sign(admin.getName()));
        tokenResult.put("username",currentAdmin.getName());
        tokenResult.put("password",admin.getPwd());
        log.info("tokenResult:{}",tokenResult);
        return tokenResult;
    }

    @Override
    public Map<String, String> info(String token) {
        String adminName = JwtUtils.getUsername(token);
        //log.info("adminName:{}" ,adminName);
        String avatarUrl = "https://upen.caup.net/ai_pics_mj/202303/1677952366325269.jpg";
        Map<String,String> baseInfo = new HashMap<>();
        baseInfo.put("name",adminName);
        baseInfo.put("avatar",avatarUrl);

        return baseInfo;
    }

    @Override
    public Map<String, String> logout(String token) {
        String username = JwtUtils.getUsername(token);
        Map<String,String> tokenResult = new HashMap<>();
        tokenResult.put("token",JwtUtils.sign(username));
        return tokenResult;
    }
}

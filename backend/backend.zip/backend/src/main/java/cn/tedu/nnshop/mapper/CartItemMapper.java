package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.CartItem;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
public interface CartItemMapper extends BaseMapper<CartItem> , MPJBaseMapper<CartItem> {

}

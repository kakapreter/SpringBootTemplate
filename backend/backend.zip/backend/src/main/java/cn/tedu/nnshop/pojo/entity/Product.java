package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("product")
public class Product implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @TableId(value = "product_id", type = IdType.AUTO)
    private Integer productId;

    @TableField("order_item_id")
    private Integer orderItemId;

    @TableField("product_manage_id")
    private Integer productManageId;

    @TableField("category_id")
    private Integer categoryId;

    @TableField("record_id")
    private Integer recordId;

    @TableField("product_name")
    private String productName;

    @TableField("product_details")
    private String productDetails;

    @TableField("product_price")
    private Float productPrice;

    @TableField("product_total")
    private Integer productTotal;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;


}

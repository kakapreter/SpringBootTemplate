package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("product")
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "product_id", type = IdType.AUTO)
    private Integer productId;

    @TableField("orderItem_id")
    private Integer orderitemId;

    @TableField("productManage_id")
    private Integer productmanageId;

    @TableField("cotegory_id")
    private Integer cotegoryId;

    @TableField("record_id")
    private Integer recordId;

    @TableField("product_name")
    private String productName;

    @TableField("product_detials")
    private String productDetials;

    @TableField("product_price")
    private Float productPrice;

    @TableField("product_total")
    private Integer productTotal;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;


}

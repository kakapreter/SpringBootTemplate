package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 属性
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("nnp_attribute")
public class NnpAttribute implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 所属属性模版id
     */
    @TableField("template_id")
    private Long templateId;

    /**
     * 属性名称
     */
    @TableField("name")
    private String name;

    /**
     * 属性简介（某些属性名称可能相同，通过简介补充描述）
     */
    @TableField("description")
    private String description;

    /**
     * 属性类型，1=销售属性，0=非销售属性
     */
    @TableField("type")
    private Integer type;

    /**
     * 输入类型，0=手动录入，1=单选，2=多选，3=单选（下拉列表），4=多选（下拉列表）
     */
    @TableField("input_type")
    private Integer inputType;

    /**
     * 备选值列表
     */
    @TableField("value_list")
    private String valueList;

    /**
     * 计量单位
     */
    @TableField("unit")
    private String unit;

    /**
     * 排序序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 是否允许自定义，1=允许，0=禁止
     */
    @TableField("is_allow_customize")
    private Integer isAllowCustomize;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

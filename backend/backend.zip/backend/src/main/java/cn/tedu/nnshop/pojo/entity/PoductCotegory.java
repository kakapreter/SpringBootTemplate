package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-13
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("poduct_cotegory")
public class PoductCotegory implements Serializable {

    private static final long serialVersionUID = 1L;

    @TableId(value = "cotegory_id", type = IdType.ASSIGN_ID)
    private Integer cotegoryId;

    @TableField("cotegory_name")
    private String cotegoryName;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;


}

package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import lombok.*;
import lombok.experimental.Accessors;

/**
 * <p>
 * SKU（Stock Keeping Unit）
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("nnp_sku")
public class NnpSku implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.ASSIGN_ID)
    private Long id;

    /**
     * SPU id
     */
    @TableField("spu_id")
    private Long spuId;

    /**
     * 标题
     */
    @TableField("title")
    private String title;

    /**
     * 条型码
     */
    @TableField("bar_code")
    private String barCode;

    /**
     * 属性模版id
     */
    @TableField("attribute_template_id")
    private Long attributeTemplateId;

    /**
     * 全部属性，使用JSON格式表示（冗余）
     */
    @TableField("specifications")
    private String specifications;

    /**
     * 相册id
     */
    @TableField("album_id")
    private Long albumId;

    /**
     * 组图URLs，使用JSON格式表示
     */
    @TableField("pictures")
    private String pictures;

    /**
     * 单价
     */
    @TableField("price")
    private BigDecimal price;

    /**
     * 当前库存
     */
    @TableField("stock")
    private Integer stock;

    /**
     * 库存预警阈值
     */
    @TableField("stock_threshold")
    private Integer stockThreshold;

    /**
     * 销量（冗余）
     */
    @TableField("sales")
    private Integer sales;

    /**
     * 买家评论数量总和（冗余）
     */
    @TableField("comment_count")
    private Integer commentCount;

    /**
     * 买家好评数量总和（冗余）
     */
    @TableField("positive_comment_count")
    private Integer positiveCommentCount;

    /**
     * 排序序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

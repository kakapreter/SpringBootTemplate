package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.NnaPermission;
import cn.tedu.nnshop.mapper.NnaPermissionMapper;
import cn.tedu.nnshop.service.NnaPermissionService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 权限 服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class NnaPermissionServiceImpl extends MPJBaseServiceImpl<NnaPermissionMapper, NnaPermission> implements NnaPermissionService {

}

package cn.tedu.nnshop.pojo.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

@Getter
@Setter
@Accessors(chain = true)
@TableName("user")
public class UserDetailsDTO {
    @TableField("name")
    private String name;

    @TableField("pwd")
    private String pwd;

}

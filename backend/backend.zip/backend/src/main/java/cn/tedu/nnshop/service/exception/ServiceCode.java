package cn.tedu.nnshop.service.exception;

import lombok.Getter;

/**
 * 业务状态码枚举类型
 */
@Getter
public enum ServiceCode {
    /**
     * 成功
     */
    OK(20000),
    /**
     * 错误: 请求参数格式错误
     */
    ERR_BAD_REQUEST(40000),
    /**
     * 错误: 登录失败, 用户名或密码错误
     */
    ERR_UNAUTHORIZED(40100),
    /**
     * 错误: 登录失败, 用户被禁用
     */
    ERR_UNAUTHORIZED_DISABLED(40101),
    /**
     * 错误: 无权限
     */
    ERR_FORBIDDEN(40300),
    /**
     * 错误: 数据不存在
     */
    ERR_NOT_FOUND(40400),
    /**
     * 错误: 数据冲突
     */
    ERR_CONFLICT(40900),
    /**
     * 错误: 数据冲突, 已经存在
     */
    ERR_EXISTS(40901),
    /**
     * 错误: 数据冲突, 已经关联
     */
    ERR_IS_ASSOCIATED(40902),
    /**
     * 错误: 插入数据错误
     */
    ERR_SAVE_FAILED(50000),
    /**
     * 错误: 删除数据错误
     */
    ERR_DELETE_FAILED(50100),
    /**
     * 错误: 修改数据错误
     */
    ERR_UPDATE_FAILED(50200),
    /**
     * 错误: 文件上传错误
     */
    ERR_FILE_UPLOAD(50300),
    /**
     * 错误: JWT已过期
     */
    ERR_JWT_EXPIRED(60000),
    /**
     * 错误: 验证签名失败
     */
    ERR_JWT_SIGNATURE(60100),
    /**
     * 错误: JWT格式错误
     */
    ERR_JWT_MALFORMED(60200),
    /**
     * 错误: JWT以退出登录
     */
    ERR_JWT_LOGOUT(60300),
    /**
     * 错误: 未知错误
     */
    ERR_UNKNOWN(99999);

    private Integer value;
    ServiceCode(Integer value) {
        this.value = value;
    }
}
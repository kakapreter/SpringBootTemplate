package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("product_image")
public class ProductImage implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;

    @TableId(value = "img_id", type = IdType.ASSIGN_ID)
    private Integer imgId;

    @TableField("product_id")
    private Integer productId;

    @TableField("url")
    private String url;

    @TableField("create_time")
    private LocalDateTime createTime;

    @TableField("update_time")
    private LocalDateTime updateTime;


}

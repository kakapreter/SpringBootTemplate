package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.NnpSpu;
import cn.tedu.nnshop.mapper.NnpSpuMapper;
import cn.tedu.nnshop.service.NnpSpuService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * SPU（Standard Product Unit） 服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class NnpSpuServiceImpl extends MPJBaseServiceImpl<NnpSpuMapper, NnpSpu> implements NnpSpuService {

}

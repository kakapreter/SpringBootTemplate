package cn.tedu.nnshop.exception;


import lombok.Getter;

//这个枚举类中定义的都是跟业务有关的异常
@Getter
public enum AppExceptionCodeMsg {
    OK(20000,"成功"),
    ERR_BAD_REQUEST(40000,"请求参数格式错误"),
    ERR_UNAUTHORIZED(40100,"登录失败, 用户名或密码错误"),
    ERR_UNAUTHORIZED_DISABLED(40101,"登录失败, 用户被禁用"),
    ERR_FORBIDDEN(40300,"无权限"),
    ERR_NOT_FOUND(40400,"数据不存在"),
    ERR_CONFLICT(40900,"数据冲突"),
    ERR_EXISTS(40901,"数据冲突, 已经存在"),
    ERR_IS_ASSOCIATED(40902,"数据冲突, 已经关联"),
    ERR_SAVE_FAILED(50010,"插入数据错误"),
    ERR_DELETE_FAILED(50100,"删除数据错误"),
    ERR_UPDATE_FAILED(50200,"修改数据错误"),
    ERR_FILE_UPLOAD(50300,"文件上传错误"),
    ERR_JWT_EXPIRED(60000,"JWT已过期"),
    ERR_JWT_SIGNATURE(60100,"验证签名失败"),
    ERR_JWT_MALFORMED(60200,"JWT格式错误"),
    ERR_JWT_LOGOUT(60300,"JWT已退出登录"),
    ERR_UNKNOWN(99999,"未知错误")
    ;

    private final int code ;
    private final String msg ;

    AppExceptionCodeMsg(int code, String msg){
        this.code = code;
        this.msg = msg;
    }

}

package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.Orders;
import cn.tedu.nnshop.mapper.OrdersMapper;
import cn.tedu.nnshop.service.OrdersService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class OrdersServiceImpl extends MPJBaseServiceImpl<OrdersMapper, Orders> implements OrdersService {

}

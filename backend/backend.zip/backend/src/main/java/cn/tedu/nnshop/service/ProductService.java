package cn.tedu.nnshop.service;

import cn.tedu.nnshop.pojo.entity.Product;
import com.github.yulichang.extension.mapping.base.MPJDeepService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
public interface ProductService extends MPJDeepService<Product> {

}

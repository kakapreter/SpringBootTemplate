package cn.tedu.nnshop.service.exception;

import lombok.Getter;

/**
 * 业务类异常
 */

@Getter
public class ServiceException extends RuntimeException {
    /**
     * 业务状态码
     */
    private final ServiceCode serviceCode;
    public ServiceException(ServiceCode serviceCode, String message) {
        super(message);
        this.serviceCode = serviceCode;
    }
}
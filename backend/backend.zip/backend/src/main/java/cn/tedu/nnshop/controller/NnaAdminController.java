package cn.tedu.nnshop.controller;

import cn.tedu.nnshop.exception.AppException;
import cn.tedu.nnshop.exception.AppExceptionCodeMsg;
import cn.tedu.nnshop.pojo.dto.AdminDetailsDTO;
import cn.tedu.nnshop.pojo.dto.AdminLoginDTO;
import cn.tedu.nnshop.pojo.dto.AdminRegisterDTO;
import cn.tedu.nnshop.pojo.entity.NnaAdmin;
import cn.tedu.nnshop.pojo.vo.NnaAdminDetailsVO;
import cn.tedu.nnshop.response.JsonResult;
import cn.tedu.nnshop.service.NnaAdminService;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Slf4j
//跨域配置
@CrossOrigin
@RestController
@RequestMapping("/api/admin")
@Api(value = "测试controller",tags = {"管理员用户接口"})
public class NnaAdminController {
    @Autowired
    private NnaAdminService nnaAdminService;

    //insert
    @ApiOperation("注册管理员")
    @PutMapping("/add")
    public JsonResult<Void> addAdmin(@RequestBody AdminRegisterDTO admin){
        //log.info("admin:{}",admin);
        boolean saved = nnaAdminService.addAdmin(admin);
        if (!saved){
            throw new AppException(AppExceptionCodeMsg.ERR_SAVE_FAILED);
        }
        return JsonResult.success(20000,"注册成功");
    }

    //delete
    @ApiOperation("根据id删除管理员")
    @DeleteMapping("/del/{id}")
    public JsonResult<Void> deleteAdminById(@PathVariable(name = "id") Integer id){
        //log.info("id:{}",id);
        boolean delAdmin = nnaAdminService.deleteAdminById(id);
        if (delAdmin){
            throw new AppException(AppExceptionCodeMsg.ERR_DELETE_FAILED);
        }
        return JsonResult.success(20000,"删除成功");
    }

    //update
    @ApiOperation("根据id修改管理员详细信息")
    @PutMapping("/upd/{id}")
    public JsonResult<Void> updateUserDetailsById(@PathVariable(name = "id") Integer id, @RequestBody AdminDetailsDTO adminDetailsDTO){
        //log.info("id:{},adminDetailsDTO:{}",id,adminDetailsDTO);
        boolean updated = nnaAdminService.updateUserDetailsById(id,adminDetailsDTO);
        if (!updated){
            throw new AppException(AppExceptionCodeMsg.ERR_UPDATE_FAILED);
        }
        return JsonResult.success(20000,"修改成功");
    }

    //select
    @ApiOperation("根据id查询管理员详细信息")
    @GetMapping("/list/{id}")
    public JsonResult<NnaAdminDetailsVO> listUserDetailsById(@PathVariable(name = "id") Integer id){
        //log.info("id:{}",id);
        NnaAdminDetailsVO adminDetailsVO = nnaAdminService.listUserDetailsById(id);
        return JsonResult.success(adminDetailsVO);
    }

    @ApiOperation("分页查询所有管理员")
    @GetMapping("/list/{current}/{size}")
    public JsonResult<Page<NnaAdmin>> listAllAdminPage(@PathVariable(name = "current") Long current, @PathVariable(name = "size")Long size){
        //log.info("current:{},size:{}",current,size);
        return JsonResult.success(nnaAdminService.listAllAdminPage(current,size));
    }
    // http://localhost:8088/api/admin/login
    @ApiOperation("登录接口")
    @PostMapping("/login")
    public JsonResult<Map<String,String>> loginByUsername(@RequestBody AdminLoginDTO admin){
        //log.info("admin:{}",admin);
        Map<String, String> tokenResult = nnaAdminService.loginByUsername(admin);
        return JsonResult.success(tokenResult);
    }

    @ApiOperation("返回管理员与头像")
    @GetMapping("/info")
    public JsonResult<Map<String, String>> info(String token){
        //log.info("token:{}",token);
        Map<String, String> baseInfo = nnaAdminService.info(token);
        return JsonResult.success(baseInfo);
    }

    @ApiOperation("退出登录")
    @PostMapping("/logout")
    public JsonResult<Map<String,String>> logout(String token){
        //log.info("token:{}",token);
        Map<String, String> tokenResult = nnaAdminService.logout(token);
        return JsonResult.success(tokenResult);
    }

}

package cn.tedu.nnshop.controller;

import cn.tedu.nnshop.pojo.entity.NnaAdmin;
import cn.tedu.nnshop.pojo.vo.NnaAdminDetailsVO;
import cn.tedu.nnshop.service.NnaAdminService;
import cn.tedu.nnshop.utils.JsonResult;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Slf4j
//跨域配置
@CrossOrigin
@RestController
@RequestMapping("/api/admin")

public class NnaAdminController {
    @Autowired
    private NnaAdminService nnaAdminService;


    @GetMapping("/list/{id}")
    public JsonResult<NnaAdminDetailsVO> listUserById(@PathVariable(name = "id") Integer id){
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getId,id);
        NnaAdmin admin = nnaAdminService.getOne(wrapper);
        log.info("admin:{}",admin);
        NnaAdminDetailsVO adminDetailsVO = new NnaAdminDetailsVO();
        adminDetailsVO.setId(admin.getId());
        adminDetailsVO.setPwd(admin.getPwd());
        adminDetailsVO.setPhone(admin.getPhone());
        adminDetailsVO.setName(admin.getName());
        adminDetailsVO.setEmail(admin.getEmail());
        adminDetailsVO.setNickname(admin.getNickname());
        return JsonResult.ok(adminDetailsVO);
    }
}

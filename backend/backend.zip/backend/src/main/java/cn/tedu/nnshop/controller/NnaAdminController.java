package cn.tedu.nnshop.controller;

import cn.tedu.nnshop.exception.AppException;
import cn.tedu.nnshop.exception.AppExceptionCodeMsg;
import cn.tedu.nnshop.pojo.entity.NnaAdmin;
import cn.tedu.nnshop.pojo.vo.NnaAdminDetailsVO;
import cn.tedu.nnshop.response.JsonResult;
import cn.tedu.nnshop.service.NnaAdminService;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Slf4j
//跨域配置
@CrossOrigin
@RestController
@RequestMapping("/api/admin")
@Api(value = "测试controller",tags = {"管理员用户接口"})
public class NnaAdminController {
    @Autowired
    private NnaAdminService nnaAdminService;

    //select
    @ApiOperation("根据id查询管理员用户详细信息")
    @GetMapping("/list/{id}")
    public JsonResult<NnaAdminDetailsVO> updateUserDetailsById(@PathVariable(name = "id") Integer id){
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getId,id);
        NnaAdmin admin = nnaAdminService.getOne(wrapper);
        if(admin==null){
            throw new AppException(AppExceptionCodeMsg.ERR_NOT_FOUND);
        }
        log.info("admin:{}",admin);
        NnaAdminDetailsVO adminDetailsVO = new NnaAdminDetailsVO();
        adminDetailsVO.setId(admin.getId());
        adminDetailsVO.setPwd(admin.getPwd());
        adminDetailsVO.setPhone(admin.getPhone());
        adminDetailsVO.setName(admin.getName());
        adminDetailsVO.setEmail(admin.getEmail());
        adminDetailsVO.setNickname(admin.getNickname());
        return JsonResult.success(adminDetailsVO);
    }
}

package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 类别
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("nnp_attribute_template")
public class NnpAttributeTemplate implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 类别名称
     */
    @TableField("name")
    private String name;

    /**
     * 关键词列表，各关键词使用英文的逗号分隔
     */
    @TableField("keywords")
    private String keywords;

    /**
     * 排序序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.InventoryRecord;
import cn.tedu.nnshop.mapper.InventoryRecordMapper;
import cn.tedu.nnshop.service.InventoryRecordService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-14
 */
@Service
public class InventoryRecordServiceImpl extends MPJBaseServiceImpl<InventoryRecordMapper, InventoryRecord> implements InventoryRecordService {

}

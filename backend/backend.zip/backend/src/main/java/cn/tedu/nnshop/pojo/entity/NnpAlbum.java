package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;
import lombok.Getter;
import lombok.Setter;
import lombok.experimental.Accessors;

/**
 * <p>
 * 相册
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Getter
@Setter
@Accessors(chain = true)
@TableName("nnp_album")
public class NnpAlbum implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * 相册名称
     */
    @TableField("name")
    private String name;

    /**
     * 相册简介
     */
    @TableField("description")
    private String description;

    /**
     * 排序序号
     */
    @TableField("sort")
    private Integer sort;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.NnaAdminRole;
import cn.tedu.nnshop.mapper.NnaAdminRoleMapper;
import cn.tedu.nnshop.service.NnaAdminRoleService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 管理员角色关联 服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class NnaAdminRoleServiceImpl extends MPJBaseServiceImpl<NnaAdminRoleMapper, NnaAdminRole> implements NnaAdminRoleService {

}

package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.NnaRolePermission;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * 角色权限关联 Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */

public interface NnaRolePermissionMapper extends BaseMapper<NnaRolePermission> , MPJBaseMapper<NnaRolePermission> {

}

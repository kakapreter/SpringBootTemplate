package cn.tedu.nnshop.utils;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import java.util.Date;

public class JwtUtils {
    private static String secret = "afiwwqisaoaszzz1123";
    /** * 校验token是否正确 * @param token 密钥 * @param username 用户名 * @param secret 密码 * @return 是否正确 */
    public static boolean verify(String token, String username, String secret) {
        try {
            Algorithm algorithm = Algorithm.HMAC256(secret);
            JWTVerifier verifier = JWT.require(algorithm)
                    .withClaim("username", username)
                    .build();
            DecodedJWT jwt = verifier.verify(token);
            return true;
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
    }

    /** * 获取token中的用户名 * @param token 密钥 * @return 用户名 */
    public static String getUsername(String jwtToken) {
        try {
            DecodedJWT decodedJWT = JWT.decode(jwtToken);
            Claim usernameClaim = decodedJWT.getClaim("username");
            if (!usernameClaim.isNull()) {
                return usernameClaim.asString();
            } else {
                // 如果用户名声明不存在，可以返回null或者进行其他处理
                return null;
            }
        } catch (Exception e) {
            // JWT解析失败，可以根据需要处理异常
            return null;
        }
    }

    /** * 生成签名 * @param username 用户名 * @param secret 密码 * @return 加密的token */
    public static String sign(String username) {
        Date date = new Date(System.currentTimeMillis() + 5*60*1000);//5分钟过期
        try {
            Algorithm algorithm = Algorithm.HMAC256(secret);
            return JWT.create()
                    .withClaim("username", username)
                    .withExpiresAt(date)
                    .sign(algorithm);
        } catch (Exception e) {
            e.getStackTrace();
        }
        return null;
    }
}

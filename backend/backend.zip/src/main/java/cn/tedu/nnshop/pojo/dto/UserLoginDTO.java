package cn.tedu.nnshop.pojo.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;


@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("user")
public class UserLoginDTO {
    @JsonProperty("username")
    @TableField("name")
    private String name;

    @JsonProperty("password")
    @TableField("pwd")
    private String pwd;
}

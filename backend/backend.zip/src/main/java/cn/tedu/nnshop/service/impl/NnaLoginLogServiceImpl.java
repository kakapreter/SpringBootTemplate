package cn.tedu.nnshop.service.impl;

import cn.tedu.nnshop.pojo.entity.NnaLoginLog;
import cn.tedu.nnshop.mapper.NnaLoginLogMapper;
import cn.tedu.nnshop.service.NnaLoginLogService;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 * 管理员登录日志 服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Service
public class NnaLoginLogServiceImpl extends MPJBaseServiceImpl<NnaLoginLogMapper, NnaLoginLog> implements NnaLoginLogService {

}

package cn.tedu.nnshop.controller;

import cn.tedu.nnshop.exception.AppException;
import cn.tedu.nnshop.exception.AppExceptionCodeMsg;
import cn.tedu.nnshop.pojo.dto.AdminDetailsDTO;
import cn.tedu.nnshop.pojo.dto.AdminLoginDTO;
import cn.tedu.nnshop.pojo.dto.AdminRegisterDTO;
import cn.tedu.nnshop.pojo.entity.NnaAdmin;
import cn.tedu.nnshop.pojo.vo.NnaAdminDetailsVO;
import cn.tedu.nnshop.response.JsonResult;
import cn.tedu.nnshop.service.NnaAdminService;
import cn.tedu.nnshop.utils.JwtUtils;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.core.conditions.update.LambdaUpdateWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Slf4j
//跨域配置
@CrossOrigin
@RestController
@RequestMapping("/api/admin")
@Api(value = "测试controller",tags = {"管理员用户接口"})
public class NnaAdminController {
    @Autowired
    private NnaAdminService nnaAdminService;

    //insert
    @ApiOperation("注册管理员")
    @PutMapping("/add")
    public JsonResult<Void> addAdmin(@RequestBody AdminRegisterDTO admin){
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getName,admin.getName());
        NnaAdmin existAdmin = nnaAdminService.getOne(wrapper);
        if (existAdmin != null){
            throw new AppException(AppExceptionCodeMsg.ERR_EXISTS);
        }
        NnaAdmin registerAdmin = new NnaAdmin();
        registerAdmin.setName(admin.getName());
        registerAdmin.setPwd(admin.getPwd());
        registerAdmin.setNickname(admin.getNickname());
        registerAdmin.setEmail(admin.getEmail());
        registerAdmin.setPhone(admin.getPhone());
        registerAdmin.setUpdateTime(new Date());
        registerAdmin.setGmtCreate(new Date());
        boolean saved = nnaAdminService.save(registerAdmin);
        if (!saved){
            throw new AppException(AppExceptionCodeMsg.ERR_SAVE_FAILED);
        }
        return JsonResult.success(20000,"注册成功");
    }

    //delete
    @ApiOperation("根据id删除管理员")
    @DeleteMapping("/del/{id}")
    public JsonResult<Void> deleteAdminById(@PathVariable(name = "id") Integer id){
        boolean delAdmin = nnaAdminService.removeById(id);
        if (delAdmin){
            throw new AppException(AppExceptionCodeMsg.ERR_DELETE_FAILED);
        }
        return JsonResult.success(20000,"删除成功");
    }

    //update
    @ApiOperation("根据id修改管理员详细信息")
    @PutMapping("/upd/{id}")
    public JsonResult<Void> updateUserDetailsById(@PathVariable(name = "id") Integer id, @RequestBody AdminDetailsDTO adminDetailsDTO){
        LambdaUpdateWrapper<NnaAdmin> wrapper = new LambdaUpdateWrapper<>();
        wrapper.set(NnaAdmin::getName,adminDetailsDTO.getName())
                .set(NnaAdmin::getPwd,adminDetailsDTO.getPwd())
                .set(NnaAdmin::getEmail,adminDetailsDTO.getEmail())
                .set(NnaAdmin::getNickname,adminDetailsDTO.getNickname())
                .set(NnaAdmin::getPhone,adminDetailsDTO.getPhone())
                .eq(NnaAdmin::getId,id);
        boolean updated = nnaAdminService.update(wrapper);
        if (!updated){
            throw new AppException(AppExceptionCodeMsg.ERR_UPDATE_FAILED);
        }
        return JsonResult.success(20000,"修改成功");
    }

    //select
    @ApiOperation("根据id查询管理员详细信息")
    @GetMapping("/list/{id}")
    public JsonResult<NnaAdminDetailsVO> listUserDetailsById(@PathVariable(name = "id") Integer id){
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getId,id);
        NnaAdmin admin = nnaAdminService.getOne(wrapper);
        if(admin==null){
            throw new AppException(AppExceptionCodeMsg.ERR_NOT_FOUND);
        }
        log.info("admin:{}",admin);
        NnaAdminDetailsVO adminDetailsVO = new NnaAdminDetailsVO();
        adminDetailsVO.setId(admin.getId());
        adminDetailsVO.setPwd(admin.getPwd());
        adminDetailsVO.setPhone(admin.getPhone());
        adminDetailsVO.setName(admin.getName());
        adminDetailsVO.setEmail(admin.getEmail());
        adminDetailsVO.setNickname(admin.getNickname());
        return JsonResult.success(adminDetailsVO);
    }

    @ApiOperation("查询所有管理员")
    @GetMapping("/list")
    public JsonResult<List<NnaAdmin>> listAllAdmin(){
        return JsonResult.success(nnaAdminService.list(null));
    }

    @ApiOperation("分页查询所有管理员")
    @GetMapping("/list/{current}/{size}")
    public JsonResult<Page<NnaAdmin>> listAllAdmin(@PathVariable(name = "current") Long current, @PathVariable(name = "size")Long size){
        return JsonResult.success(nnaAdminService.page(new Page<>(current, size)));
    }

    @ApiOperation("登录接口")
    @PostMapping("/login")
    public JsonResult<Map<String,String>> loginByUsername(@RequestBody AdminLoginDTO admin){
        LambdaQueryWrapper<NnaAdmin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(NnaAdmin::getName,admin.getName())
                .eq(NnaAdmin::getPwd,admin.getPwd());
        NnaAdmin currentAdmin = nnaAdminService.getOne(wrapper);
        if (currentAdmin == null){
            throw new AppException(AppExceptionCodeMsg.ERR_UNAUTHORIZED);
        }
        Map<String,String> tokenResult = new HashMap<>();
        tokenResult.put("token", JwtUtils.sign(admin.getName()));
        tokenResult.put("username",currentAdmin.getName());
        tokenResult.put("password",admin.getPwd());
        return JsonResult.success(tokenResult);
    }

    @ApiOperation("返回管理员与头像")
    @GetMapping("/info")
    public JsonResult<Map<String, String>> info(String token){
        String adminName = JwtUtils.getUsername(token);
        //log.info("adminName:{}" ,adminName);
        String avatarUrl = "https://upen.caup.net/ai_pics_mj/202303/1677952366325269.jpg";
        Map<String,String> baseInfo = new HashMap<>();
        baseInfo.put("name",adminName);
        baseInfo.put("avatar",avatarUrl);
        return JsonResult.success(baseInfo);
    }

    @ApiOperation("退出登录")
    @PostMapping("/logout")
    public JsonResult<Map<String,String>> logout(String token){
        String username = JwtUtils.getUsername(token);
        Map<String,String> tokenResult = new HashMap<>();
        tokenResult.put("token",JwtUtils.sign(username));
        return JsonResult.success(tokenResult);
    }

}

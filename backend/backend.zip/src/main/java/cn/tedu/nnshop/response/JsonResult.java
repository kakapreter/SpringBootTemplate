package cn.tedu.nnshop.response;

import cn.tedu.nnshop.exception.AppExceptionCodeMsg;
import lombok.Getter;

import java.util.HashMap;
import java.util.Map;


@Getter
public class JsonResult<T> {

    //服务端返回的错误码
    private int code = 20000;
    //服务端返回的错误信息
    private String msg = "success";
    //我们服务端返回的数据
    private final T data;

    private JsonResult(int code,String msg,T data){
        this.code = code;
        this.msg = msg;
        this.data = data;
    }

    private JsonResult(int code,String msg){
        this.code = code;
        this.msg = msg;
        this.data = null;
    }

    public static JsonResult<Void> success(){
        return null;
    }

    public static <T> JsonResult<T> success(int code,String msg){
        return new JsonResult<T>(20000, "success");
    }

    public static <T> JsonResult<T> success(T data){
        return new JsonResult<T>(20000, "success", data);
    }

    public static <T> JsonResult<T> success(String msg,T data){
        return new JsonResult<T>(20000,msg, data);
    }

    public static <T> JsonResult<T> error(AppExceptionCodeMsg appExceptionCodeMsg){
        return new JsonResult<T>(appExceptionCodeMsg.getCode(), appExceptionCodeMsg.getMsg(), null);
    }
    public static <T> JsonResult<T> error(int code,String msg){
        return new JsonResult<T>(code,msg, null);
    }

}


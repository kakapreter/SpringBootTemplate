package cn.tedu.nnshop.pojo.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;
import lombok.experimental.Accessors;
import org.springframework.stereotype.Component;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("nna_admin")
public class AdminDetailsDTO {

    @JsonProperty("username")
    @TableField("name")
    private String name;

    @JsonProperty("password")
    @TableField("pwd")
    private String pwd;

    @JsonProperty("nickname")
    @TableField("nickname")
    private String nickname;

    @JsonProperty("email")
    @TableField("email")
    private String email;

    @JsonProperty("phone")
    @TableField("phone")
    private String phone;
}

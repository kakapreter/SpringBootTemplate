package cn.tedu.nnshop.pojo.vo;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.*;
import lombok.experimental.Accessors;

import java.io.Serializable;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("user")
public class UserLoginVO implements Serializable {
    @TableField("name")
    private String name;

    @TableField("pwd")
    private String pwd;
}

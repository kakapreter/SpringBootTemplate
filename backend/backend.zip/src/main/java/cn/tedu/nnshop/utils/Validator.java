package cn.tedu.nnshop.utils;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import org.springframework.stereotype.Component;
import java.util.regex.Pattern;

@Component
public class Validator {
    private final String EMAIL_PATTERN = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
    private final Pattern patternEmail = Pattern.compile(EMAIL_PATTERN);




    public  boolean validateEmail(String email) {
        if (StringUtils.isEmpty(email)){
            return false;
        }
        return patternEmail.matcher(email).matches();
    }


    public  boolean validatePhone(String phone){
        Pattern p = Pattern.compile("^[1](([3-9][\\d])|([4][5,6,7,8,9])|([6][5,6])|([7][3,4,5,6,7,8])|([9][8,9]))[\\d]{8}$");
        return p.matcher(phone).matches();
    }
}
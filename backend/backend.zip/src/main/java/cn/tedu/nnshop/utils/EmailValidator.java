package cn.tedu.nnshop.utils;

import com.baomidou.mybatisplus.core.toolkit.StringUtils;
import org.springframework.stereotype.Component;
import java.util.regex.Pattern;

@Component
public class EmailValidator {
    private final String EMAIL_PATTERN = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
    private final Pattern pattern = Pattern.compile(EMAIL_PATTERN);

    public  boolean validateEmail(String email) {
        if (StringUtils.isEmpty(email)){
            return false;
        }
        return pattern.matcher(email).matches();
    }
}
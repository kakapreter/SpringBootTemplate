package cn.tedu.nnshop.service;

import cn.tedu.nnshop.pojo.dto.AdminDetailsDTO;
import cn.tedu.nnshop.pojo.dto.AdminLoginDTO;
import cn.tedu.nnshop.pojo.dto.AdminRegisterDTO;
import cn.tedu.nnshop.pojo.entity.NnaAdmin;
import cn.tedu.nnshop.pojo.vo.NnaAdminDetailsVO;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.IService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import com.github.yulichang.extension.mapping.base.MPJDeepService;

import java.util.Map;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
public interface NnaAdminService extends MPJDeepService<NnaAdmin> {
    boolean addAdmin(AdminRegisterDTO admin);
    boolean deleteAdminById(Integer id);
    boolean updateUserDetailsById(Integer id, AdminDetailsDTO adminDetailsDTO);
    NnaAdminDetailsVO listUserDetailsById(Integer id);
    Page<NnaAdmin> listAllAdminPage(Long current,Long size);
    Map<String,String> loginByUsername(AdminLoginDTO admin);
    Map<String,String> info(String token);
    Map<String,String> logout(String token);

}

package cn.tedu.nnshop.mapper;

import cn.tedu.nnshop.pojo.entity.NnpSpu;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;
import org.apache.ibatis.annotations.Mapper;

/**
 * <p>
 * SPU（Standard Product Unit） Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */

public interface NnpSpuMapper extends BaseMapper<NnpSpu> , MPJBaseMapper<NnpSpu> {

}

package cn.tedu.nnshop.pojo.entity;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import java.io.Serializable;
import java.util.Date;

import lombok.*;
import lombok.experimental.Accessors;

/**
 * <p>
 * SPU详情
 * </p>
 *
 * @author kakapreter
 * @since 2023-10-16
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("nnp_spu_detail")
public class NnpSpuDetail implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 数据id
     */
    @TableId(value = "id", type = IdType.AUTO)
    private Long id;

    /**
     * SPU id
     */
    @TableField("spu_id")
    private Long spuId;

    /**
     * SPU详情，应该使用HTML富文本，通常内容是若干张图片
     */
    @TableField("detail")
    private String detail;

    /**
     * 数据创建时间
     */
    @TableField("gmt_create")
    private Date gmtCreate;

    /**
     * 数据最后修改时间
     */
    @TableField("gmt_modified")
    private Date gmtModified;


}

package cn.tedu.nnshop.pojo.dto;

import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableName;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Accessors(chain = true)
@TableName("user")
public class UserDetailsDTO {

    private Long id;

    @JsonProperty("username")
    @TableField("name")
    private String name;

    @JsonProperty("password")
    @TableField("pwd")
    private String pwd;

    @TableField("roles")
    private String roles;

}

package cn.highedu.nnshop.service;

import cn.highedu.nnshop.entity.Invetoryrecord;
import com.github.yulichang.extension.mapping.base.MPJDeepService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-09-13
 */
public interface InvetoryrecordService extends MPJDeepService<Invetoryrecord> {

}

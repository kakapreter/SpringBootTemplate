package cn.highedu.nnshop.service.impl;

import cn.highedu.nnshop.entity.Invetoryrecord;
import cn.highedu.nnshop.mapper.InvetoryrecordMapper;
import cn.highedu.nnshop.service.InvetoryrecordService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-09-13
 */
@Service
public class InvetoryrecordServiceImpl extends MPJBaseServiceImpl<InvetoryrecordMapper, Invetoryrecord> implements InvetoryrecordService {

}

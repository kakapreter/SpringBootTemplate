package cn.highedu.nnshop.service.impl;

import cn.highedu.nnshop.entity.Poductcotegory;
import cn.highedu.nnshop.mapper.PoductcotegoryMapper;
import cn.highedu.nnshop.service.PoductcotegoryService;
import com.github.yulichang.base.MPJBaseServiceImpl;
import org.springframework.stereotype.Service;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author kakapreter
 * @since 2023-09-13
 */
@Service
public class PoductcotegoryServiceImpl extends MPJBaseServiceImpl<PoductcotegoryMapper, Poductcotegory> implements PoductcotegoryService {

}

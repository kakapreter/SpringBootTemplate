package cn.highedu.nnshop.mapper;

import cn.highedu.nnshop.entity.Productimage;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.github.yulichang.base.MPJBaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author kakapreter
 * @since 2023-09-13
 */
public interface ProductimageMapper extends BaseMapper<Productimage>, MPJBaseMapper<Productimage> {

}

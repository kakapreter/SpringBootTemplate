package cn.highedu.nnshop.service;

import cn.highedu.nnshop.entity.Orderitem;
import com.github.yulichang.extension.mapping.base.MPJDeepService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-09-13
 */
public interface OrderitemService extends MPJDeepService<Orderitem> {

}

# vue-admin-template

## Build Setup

```bash
# 安装依赖
npm install

# 进入项目目录
cd vue-admin-template

# 启动服务
npm run dev
```

浏览器访问 [http://localhost:9528](http://localhost:9528)

访问本地服务器
改.env.development文件中的base api
如 VUE_APP_BASE_API = 'http://localhost:8088'

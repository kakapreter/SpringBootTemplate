import request from '@/utils/request'
export function getAdminList(pageNum,pageSize,searchObj){
  return request({
    url:`/api/admin/list/${pageNum}/${pageSize}`,
    method:"get",
    params:searchObj
  })
}
export function deleteAdminByRow(currentRow){
  return request({
    url:`/api/admin/del/${currentRow}`,
    method:"delete"
  })
}

export function editAdminById(currentRow,data){
  return request({
    url:`/api/admin/upd/${currentRow}`,
    method:"put",
    data:data
  })
}

export function listAdminById(currentRow,searchObj){
  return request({
    url:`/api/admin/list/${currentRow}`,
    method:"get",
    params:searchObj
  })
}

import request from '@/utils/request'

export default {
  getAdminList(pageNum,pageSize,searchObj){
    return request({
      url:`/api/admin/list/${pageNum}/${pageSize}`,
      method:"get",
      params:searchObj
    })
  },
  deleteAdminByRow(currentRow){
    return request({
      url:`/api/admin/del/${currentRow}`,
      method:"delete"
    })
  },

}

import request from '@/utils/request'
export function getAdminList(pageNum,pageSize,searchObj){
  return request({
    url:`/api/admin/list/${pageNum}/${pageSize}`,
    method:"get",
    params:searchObj
  })
}
export function deleteAdminByRow(currentRow){
  return request({
    url:`/api/admin/del/${currentRow}`,
    method:"delete"
  })
}

export function editAdminById(currentRow){
  return request({
    url:`/api/admin/upd/${currentRow}`,
    method:"put"
  })
}

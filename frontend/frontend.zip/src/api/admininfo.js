import request from '@/utils/request'

//put
export function updAdminById(id,data){
  return request({
    url:`/api/admin/upd/${id}`,
    method:"put",
    data:data
  })
}
export function registerAdmin(data){
  return request({
    url:'/api/admin/add',
    method:'put',
    data:data
  })
}
//delete
export function deleteAdminById(id){
  return request({
    url:`/api/admin/del/${id}`,
    method:"delete"
  })
}
//get
export function adminListPage(pageNum,pageSize,params){
  return request({
    url:`/api/admin/list/${pageNum}/${pageSize}`,
    method:"get",
    params:params
  })
}
export function listAdminById(id,params){
  return request({
    url:`/api/admin/list/${id}`,
    method:"get",
    params:params
  })
}


//validate
/* 合法邮箱 */
export function validateEmail(rule, value, callback) {
  const emailReg = /^(([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5}){1,25})$/
  if (!value) {
    return callback(new Error('邮箱不能为空!'))
  }
  setTimeout(() => {
    if (!emailReg.test(value)) {
      return callback(new Error('邮箱格式错误'))
    } else {
      callback()
    }
  }, 100)
}

/* 合法手机号 */
export function validatePhone(rule, value, callback) {
  const phoneReg = /^[1][3,4,5,7,8][0-9]{9}$/
  if (!value) {
    return callback(new Error('手机号码不能为空!'))
  }
  setTimeout(() => {
    if (!phoneReg.test(value)) {
      return callback(new Error('手机号码格式错误'))
    } else {
      callback()
    }
  }, 100)
}






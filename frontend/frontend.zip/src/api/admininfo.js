import request from '@/utils/request'

//put
export function editAdminById(id,data){
  return request({
    url:`/api/admin/upd/${id}`,
    method:"put",
    data:data
  })
}
export function registerAdmin(data){
  return request({
    url:'/api/admin/add',
    method:'put',
    data:data
  })
}
//delete
export function deleteAdminById(id){
  return request({
    url:`/api/admin/del/${id}`,
    method:"delete"
  })
}
//get
export function adminListPage(pageNum,pageSize,params){
  return request({
    url:`/api/admin/list/${pageNum}/${pageSize}`,
    method:"get",
    params:params
  })
}
export function adminList(){
  return request({
    url:`/api/admin/list`,
    method:"get",
  })
}
export function listAdminById(id,params){
  return request({
    url:`/api/admin/list/${id}`,
    method:"get",
    params:params
  })
}





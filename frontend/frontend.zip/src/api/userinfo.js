import request from '@/utils/request'

export default {
  getUserList(pageNum,pageSize,searchObj){
    return request({
      url:`/api/user/list/${pageNum}/${pageSize}`,
      method:"get",
      params:searchObj
    })
  },



}

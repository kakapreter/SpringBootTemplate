<template>
    <div class="block">

      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple">
              <el-table :data="searchObj" style="width: 100%">

                <el-table-column label="姓名" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.name }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="密码" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.pwd }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="昵称" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.nickname }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="邮箱" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.email }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="电话" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.phone }}</span>
                  </template>
                </el-table-column>

                <!--右侧的编辑删除按钮-->
                <el-table-column label="操作">
                  <template slot-scope="scope">
<!--                    <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>-->

                    <!--右侧的编辑按钮-->
                    <el-button size="mini" @click="dialogFormVisible = true;handleEdit(scope.row.id,scope.row);">编辑</el-button>

<!-- ==============================================================================================  -->
                    <el-dialog center=center title="修改当前用户信息" :visible.sync="dialogFormVisible">

                      <el-form :model="currentAdmin">

                        <el-form-item label="新用户:" :label-width="formLabelWidth">
                          <el-input v-model="currentAdmin.name" autocomplete="off"></el-input>
                        </el-form-item>

                        <el-form-item label="新密码:" :label-width="formLabelWidth">
                          <el-input v-model="currentAdmin.pwd" autocomplete="off"></el-input>
                        </el-form-item>

                        <el-form-item label="新昵称:" :label-width="formLabelWidth">
                          <el-input v-model="currentAdmin.nickname" autocomplete="off"></el-input>
                        </el-form-item>

                        <el-form-item label="新邮箱:" :label-width="formLabelWidth">
                          <el-input v-model="currentAdmin.email" autocomplete="off"></el-input>
                        </el-form-item>

                        <el-form-item label="新号码:" :label-width="formLabelWidth">
                          <el-input  v-model="currentAdmin.phone" autocomplete="off"></el-input>
                        </el-form-item>

                      </el-form>

                      <div slot="footer" class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="dialogFormVisible = false;editAdminById(currentAdmin.id,currentAdmin)" >确 定</el-button>
                      </div>
                    </el-dialog>
<!-- ================================================================================================= -->

                    <!--右侧的删除按钮-->
                    <el-button size="mini" type="danger" @click="handleDelete(scope.row.id,scope.row)">删除</el-button>
<!-- ================================================================================================-->
                  </template>
                </el-table-column>

            </el-table>
        </div>
        </el-col>
      </el-row>

      <!--分页插件-->
      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current- = params.page
                :page-sizes="[10, 15, 20, 50]"
                :page-size="20"
                layout="total, sizes, prev, pager, next, jumper"
                :total = total>
              </el-pagination>
          </div>
        </el-col>
      </el-row>

    </div>

</template>

<script>
    import form from '@/views/form/index.vue'
    import { deleteAdminByRow, editAdminById, getAdminList, listAdminById } from '@/api/admininfo'
    export default {
      name:'list',
      computed: {
        form() {
          return form
        }
      },
      data(){
        return {
          //这里的参数为默认值会随着页面的方法调用进行改变model层
          params:{page:1,size:10},
          total: 20,
          current: 0,
          searchObj:[],
          currentRow:0,
          dialogFormVisible: false,
          formLabelWidth: '80px',
          isCenter:true,
          currentAdmin:{}
        }
      },
      created() {
          this.fetchData()
      },
      mounted() {

      },
      methods:{
        fetchData(){
          //请求url: `/api/admin/list/${pageNum}/${pageSize}`,在resp中拿到后端数据
          getAdminList(this.params.page,this.params.size,this.searchObj).then(resp=>{
            this.total = resp.data.total
            this.searchObj = resp.data.records
          })
        },

        handleEdit(index,row){
          //请求url: `/api/admin/list/${pageNum}/${pageSize}`,在resp中拿到后端数据
          //console.log(index)
          listAdminById(index,row).then(resp=>{
            this.currentAdmin = resp.data
            //console.log(this.currentAdmin)
          })
        },
        editAdminById(index,data){
          //console.log(index)
          //console.log(data)
          editAdminById(index,data).then()
          this.fetchData()
        },

        //分页的实现
        handleSizeChange(val){
          //console.log(val)
          this.params.size = val
          this.fetchData()
        },

        handleCurrentChange(val){
          //console.log(val)
          this.params.page = val
          this.fetchData()
        },


        //给删除用户的操作加一个后悔药
        handleDelete(index,row) {
          //console.log(index)
          //console.log(row)
          this.$confirm('此操作将永久删除该用户, 是否继续?', '提示', {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning'
          },
          ).then(() => {
            //执行删除操作
            //请求url: `/api/admin/del/${currentRow}`
            deleteAdminByRow(index)
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
            this.fetchData()
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            });
            //this.fetchData()
          });
        },



      }

    }
</script>



<style lang="scss" scoped>

</style>

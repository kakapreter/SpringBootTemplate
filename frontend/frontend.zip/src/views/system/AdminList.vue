<template>
    <div class="block">

      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple">
              <el-table :data="searchObj" style="width: 100%">

                <el-table-column label="姓名" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.name }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="密码" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.pwd }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="昵称" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.nickname }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="邮箱" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.email }}</span>
                  </template>
                </el-table-column>

                <el-table-column label="电话" width="180">
                  <template slot-scope="scope">
                    <span style="margin-left: 10px">{{ scope.row.phone }}</span>
                  </template>
                </el-table-column>


                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button size="mini" type="danger" @click="handleDelete(scope.row.id)">删除</el-button>
                  </template>
                </el-table-column>

            </el-table>
        </div>
        </el-col>
      </el-row>

      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current- = params.page
                :page-sizes="[10, 15, 20, 50]"
                :page-size="20"
                layout="total, sizes, prev, pager, next, jumper"
                :total = total>
              </el-pagination>
          </div>
        </el-col>
      </el-row>

    </div>

</template>

<script>
    import userInfoApi from '@/api/admininfo'
    export default {
      name:'list',
      data(){
        return {
          //这里的参数为默认值会随着页面的方法调用进行改变model层
          params:{page:1,size:10},
          total: 20,
          current: 0,
          searchObj:[],
          currentRow:0,
        }
      },
      created() {
          this.fetchDate()
      },
      mounted() {

      },
      methods:{
        fetchDate(){
          userInfoApi.getAdminList(this.params.page,this.params.size,this.searchObj).then(resp=>{
            this.total = resp.data.total
            this.searchObj = resp.data.records
          })
        },

        handleSizeChange(val){
          console.log(val)
          this.params.size = val
          this.fetchDate()
        },

        handleCurrentChange(val){
          this.params.page = val
          this.fetchDate()
        },

        handleDelete(index) {
          console.log(index+1)
          userInfoApi.deleteAdminByRow(index)
          this.fetchDate()
        },

      }

    }
</script>



<style lang="scss" scoped>

</style>

<template>
    <div>
      <el-table
        :data="searchObj"
        style="width: 100%">
        <el-table-column
          prop="name"
          label="姓名"
          width="180">
        </el-table-column>
        <el-table-column
          prop="pwd"
          label="密码">
        </el-table-column>
        <el-table-column
          prop="roles"
          label="身份">
        </el-table-column>
      </el-table>

    </div>

</template>

<script>
    import userInfoApi from '@/api/userinfo'
    export default {
      name:'list',
      data(){
        return {
          page: 1,
          limit: 5,
          searchObj:[{}],
        }
      },
      created() {
          this.fetchDate()

      },
      mounted() {

      },
      methods:{
        fetchDate(page = 1){
          this.page = page
          userInfoApi.getUserList(this.page,this.limit,this.searchObj).then(resp=>{
            this.total = resp.data.total
            this.limit = resp.data.limit
            this.searchObj = resp.data
          })
        }
      }

    }
</script>



<style lang="scss" scoped>

</style>

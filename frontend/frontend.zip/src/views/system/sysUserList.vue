<template>
    <div class="block">

      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple">
              <el-table :data="searchObj" style="width: 100%">

                <el-table-column prop="id" label="编号"></el-table-column>
                <el-table-column prop="name" label="姓名" width="180"></el-table-column>
                <el-table-column prop="pwd" label="密码" width="180"></el-table-column>
                <el-table-column prop="phone" label="电话"></el-table-column>
                <el-table-column prop="email" label="邮箱"></el-table-column>
                <el-table-column prop="nickname" label="昵称"></el-table-column>

                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <el-button size="mini" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
                    <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
                  </template>
                </el-table-column>

            </el-table>
        </div>
        </el-col>
      </el-row>


      <el-row>
        <el-col :span="24">
          <div class="grid-content bg-purple">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current- = params.page
                :page-sizes="[10, 15, 20, 50]"
                :page-size="20"
                layout="total, sizes, prev, pager, next, jumper"
                :total = total>
              </el-pagination>
          </div>
        </el-col>
      </el-row>

    </div>

</template>

<script>
    import userInfoApi from '@/api/userinfo'
    import th from 'element-ui/src/locale/lang/th'
    export default {
      name:'list',
      data(){
        return {
          //这里的参数为默认值会随着页面的方法调用进行改变model层
          params:{page:1,size:10},
          total: 20,
          current: 0,
          searchObj:[],
        }
      },
      created() {
          this.fetchDate()
      },
      mounted() {

      },
      methods:{
        fetchDate(){
          userInfoApi.getAdminList(this.params.page,this.params.size,this.searchObj).then(resp=>{
            this.total = resp.data.total
            this.searchObj = resp.data.records
          })
        },

        handleSizeChange(val){
          console.log(val)
          this.params.size = val
          this.fetchDate()
        },

        handleCurrentChange(val){
          this.params.page = val
          this.fetchDate()
        },

        handleEdit(index, row) {
          console.log(index, row);
        },
        handleDelete(index, row) {
          console.log(index, row);
        }

      }

    }
</script>



<style lang="scss" scoped>

</style>

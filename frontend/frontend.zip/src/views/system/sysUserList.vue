<template>
    <div class="block">
      <el-table
        :data="searchObj"
        style="width: 100%">
        <el-table-column
          prop="name"
          label="姓名"
          width="180">
        </el-table-column>
        <el-table-column
          prop="pwd"
          label="密码">
        </el-table-column>
        <el-table-column
          prop="roles"
          label="身份">
        </el-table-column>
      </el-table>

      <el-pagination
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
        :current- = params.page
        :page-sizes="[10, 50, 100, 150]"
        :page-size="20"
        layout="total, sizes, prev, pager, next, jumper"
        :total = total>
      </el-pagination>
    </div>

</template>

<script>
    import userInfoApi from '@/api/userinfo'
    import th from 'element-ui/src/locale/lang/th'
    export default {
      name:'list',
      data(){
        return {
          //这里的参数为默认值会随着页面的方法调用进行改变model层
          params:{page:1,size:10},
          total: 20,
          current: 0,
          searchObj:[],
        }
      },
      created() {
          this.fetchDate()
      },
      mounted() {

      },
      methods:{
        fetchDate(){
          userInfoApi.getUserList(this.params.page,this.params.size,this.searchObj).then(resp=>{
            this.total = resp.data.total
            this.searchObj = resp.data.records
          })
        },

        handleSizeChange(val){
          console.log(val)
          this.params.size = val
          this.fetchDate()
        },

        handleCurrentChange(val){
          this.params.page = val
          this.fetchDate()
        }

      }

    }
</script>



<style lang="scss" scoped>

</style>

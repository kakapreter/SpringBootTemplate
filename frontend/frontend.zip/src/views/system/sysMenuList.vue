<template>
  <div>菜单管理</div>
</template>

<script>
export default {

}
</script>



<style lang="scss" scoped>

</style>

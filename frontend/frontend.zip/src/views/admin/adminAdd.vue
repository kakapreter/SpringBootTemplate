<template>
  <div style="width: 100%; text-align: center; margin-top: 30px;">
    <el-form :model="adminForm" :rules="rules" ref="adminForm" label-width="100px" class="demo-ruleForm">
      <el-form-item label="姓名" prop="name">
        <el-input v-model="adminForm.name"></el-input>
      </el-form-item>
      <el-form-item label="密码" prop="pwd">
        <el-input v-model="adminForm.pwd"></el-input>
      </el-form-item>
      <el-form-item label="昵称">
        <el-input v-model="adminForm.nickname"></el-input>
      </el-form-item>
      <el-form-item label="邮箱" prop="email">
        <el-input v-model="adminForm.email"></el-input>
      </el-form-item>
      <el-form-item label="手机" prop="phone">
        <el-input v-model="adminForm.phone"></el-input>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" @click="submitForm(adminForm)">立即添加</el-button>
        <el-button @click="resetForm(adminForm)">重置</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
import { registerAdmin, validateEmail, validatePhone } from '@/api/admininfo'
export default {
  data() {
    return {
      adminForm: {
        name: '',
        pwd: '',
        nickname: '',
        email: '',
        phone:'',
        //delivery: false,
      },
      rules: {
        name: [
          { required: true, message: '请输入管理员名', trigger: 'blur' },
          { min: 3, max: 9, message: '长度在 3 到 9 个字符', trigger: 'blur' }
        ],
        pwd: [
          { required: true, message: '请输入密码', trigger: 'blur' },
          { min: 6, message: '密码不能少于6位', trigger: 'blur' }
        ],
        nickname: [
        ],
        email: [
          { required: true, trigger: 'blur' ,validator: validateEmail}
        ],
        phone: [
          { required: true, trigger: 'blur' ,validator: validatePhone},
          { min: 11, max:11 , trigger: 'blur' }
        ],
      }
    };
  },
  methods: {
    submitForm(adminForm) {
      this.$refs.adminForm.validate((valid) =>{
        if (valid) {
          registerAdmin(adminForm).then(()=>{
            this.adminForm.name = ''
            this.adminForm.pwd = ''
            this.adminForm.nickname = ''
            this.adminForm.phone = ''
            this.adminForm.email = ''

            //console.log(resp.statusText)
            this.$message({
              type: 'success',
              message: '添加成功!',
            })
          })
        } else {
          return false;
        }
      })
    },
    resetForm(admin) {
      admin.pwd = ''
      admin.name = ''
      admin.email = ''
      admin.nickname = ''
      admin.phone = ''
    },
  }
}
</script>

<style lang="scss" scoped>
.el-form {
  width: 30%;
  margin: 0 auto;
}
.container {
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100%;
}
</style>

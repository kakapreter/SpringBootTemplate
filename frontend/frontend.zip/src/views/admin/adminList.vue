<template>
    <div class="block">
          <div class="grid-content bg-purple">
              <el-table :data="admins" style="width: 100%">
                <el-table-column align="center" label="姓名" width="180">
                  <template slot-scope="scope">
                    <span>{{ scope.row.name }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="密码" width="180">
                  <template slot-scope="scope">
                    <span>{{ scope.row.pwd }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="昵称" width="180">
                  <template slot-scope="scope">
                    <span>{{ scope.row.nickname }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="邮箱" width="180">
                  <template slot-scope="scope">
                    <span>{{ scope.row.email }}</span>
                  </template>
                </el-table-column>
                <el-table-column align="center" label="电话" width="180">
                  <template slot-scope="scope">
                    <span>{{ scope.row.phone }}</span>
                  </template>
                </el-table-column>
<!--  ================================右侧的编辑删除按钮==============================================  -->
                <el-table-column align="center" label="操作">
                  <template slot-scope="scope">
                    <!--编辑按钮-->
                    <el-button size="mini" @click="dialogFormVisible = true;handleEdit(scope.row.id,scope.row);">编辑</el-button>
                    <el-dialog center=center title="修改当前管理员信息" :visible.sync="dialogFormVisible">
                      <el-form :model="currentAdmin" :rules="rules" ref="ruleForm" >
                        <el-form-item label="用户名:" :label-width="formLabelWidth">
                          <span style="margin-left: 10px">{{currentAdmin.name}}</span>
                        </el-form-item>
                        <el-form-item label="新密码:" :label-width="formLabelWidth" prop="pwd">
                          <el-input v-model="currentAdmin.pwd" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="新昵称:" :label-width="formLabelWidth">
                          <el-input v-model="currentAdmin.nickname" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="新邮箱:" :label-width="formLabelWidth" prop="email">
                          <el-input v-model="currentAdmin.email" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="新号码:" :label-width="formLabelWidth" prop="phone">
                          <el-input  v-model="currentAdmin.phone" autocomplete="off"></el-input>
                        </el-form-item>
                      </el-form>
                      <div slot="footer" class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="dialogFormVisible = false;editAdminById(currentAdmin.id,currentAdmin)" >确 定</el-button>
                      </div>
                    </el-dialog>
                    <!--删除按钮-->
                    <el-button style="margin-left: 10px" size="mini" type="danger" @click="handleDelete(scope.row.id,scope.row)">删除</el-button>
                  </template>
                </el-table-column>
<!--  =============================================================================================== -->
            </el-table>
        </div>
      <!--分页插件-->
      <el-card class="footer" v-if="total > 0">
          <div class="grid-content bg-purple">
              <el-pagination
                @size-change="handleSizeChange"
                @current-change="handleCurrentChange"
                :current- = params.page
                :page-sizes="[10]"
                :page-size="10"
                layout="total, sizes, prev, pager, next, jumper"
                :total = total>
              </el-pagination>
          </div>
      </el-card>
    </div>
</template>

<script>
    import form from '@/views/form/index.vue'
    import {
      adminListPage,
      deleteAdminById,
      listAdminById,
      updAdminById, validateEmail, validatePhone
    } from '@/api/admininfo'
    export default {
      name:'list',
      computed: {
        form() {
          return form
        }
      },
      data(){
        return {
          //这里的参数为默认值会随着页面的方法调用进行改变model层
          params:{page:1,size:10},
          total: 20,
          current: 0,
          admins:[],
          currentRow:0,
          dialogFormVisible: false,
          formLabelWidth: '80px',
          isCenter:true,
          currentAdmin:{},
          pwd:'',
          rules: {
            pwd: [
              { required: true, message: '请输入密码', trigger: 'blur' },
              { min: 6, message: '密码不能少于6位', trigger: 'blur' }
            ],
            email: [
              { required: true, trigger: 'blur' ,validator: validateEmail}
            ],
            phone: [
              { required: true, trigger: 'blur' ,validator: validatePhone},
              { min: 11, max:11 ,message: '请输入11位的手机号码', trigger: 'blur' }
            ],
          }
        }
      },
      created() {
        //数据初始化
          this.fetchData()
      },
      mounted() {

      },
      methods:{
        //获取数据
        fetchData(){
          adminListPage(this.params.page,this.params.size,this.admins).then(resp=>{
            this.total = resp.data.total
            this.admins = resp.data.records
          })
        },
        //点击编辑按钮弹出编辑框,并将当前行的数据显示在弹出的表单中
        handleEdit(id,row){
          listAdminById(id,row).then(resp=>{
            this.currentAdmin = resp.data
          })
        },
        //将当前表单中的数据提交到后端,修改数据
        editAdminById(id,data){
          console.log("index:" + id + " data:" + data)
          updAdminById(id,data).then(resp=>{
            this.$message({
              type: 'success',
              message: '修改成功!',
            })
            this.admins = resp.data.records
          })
          this.fetchData()
        },
        //给删除管理员的操作加一个后悔药
        handleDelete(id) {
          this.$confirm('此操作将永久删除该管理员, 是否继续?', '提示', {
              confirmButtonText: '确定',
              cancelButtonText: '取消',
              type: 'warning'
            },
          ).then(() => {
            //执行删除操作
            deleteAdminById(id)
            this.$message({
              type: 'success',
              message: '删除成功!'
            });
            this.fetchData()
          }).catch(() => {
            this.$message({
              type: 'info',
              message: '已取消删除'
            });
            this.admins = resp.data.records
          });
        },

        //分页插件
        handleSizeChange(val){
          //console.log(val)
          this.params.size = val
          this.fetchData()
        },
        handleCurrentChange(val){
          //console.log(val)
          this.params.page = val
          this.fetchData()
        },
      }
    }
</script>

<style lang="scss" scoped>
.footer {
  height: 60px;
  position: fixed;
  bottom: 0;
  width: 100%;
  line-height: 20px;
  color: #fff;
}
</style>

import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

/* Layout */
import Layout from '@/layout'

/**
 * constantRoutes
 * a base page that does not have permission requirements
 * all roles can be accessed
 *
 * 常量路由
 * 没有权限要求的基页
 * 所有角色都可以访问
 */
export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/404',
    component: () => import('@/views/404'),
    hidden: true
  },
  {
    path: '/',
    component: Layout,
    redirect: '/dashboard',
    children: [{
      path: 'dashboard',
      name: '仪表盘',
      component: () => import('@/views/dashboard/index'),
      //title显示的是左侧的文字
      meta: { title: '仪表盘', icon: 'dashboard' }
    }]
  },
  {
    path: '/',
    component: Layout,
    meta: { title: '管理员管理', icon: 'el-icon-s-help' },
    children: [
      {
        path: '/AdminManage/AdminList',
        name: 'AdminList',
        component: () => import('@/views/admin/adminList.vue'),
        meta: { title: '管理员列表', icon: 'table' }
      },
      {
        path: '/AdminManage/AdminAdd',
        name: 'AdminAdd',
        component: () => import('@/views/admin/adminAdd.vue'),
        meta: { title: '管理员添加', icon: 'el-icon-s-help' }
      }
    ]
  },

]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

// Detail see: https://github.com/vuejs/vue-router/issues/1234#issuecomment-357941465
export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router


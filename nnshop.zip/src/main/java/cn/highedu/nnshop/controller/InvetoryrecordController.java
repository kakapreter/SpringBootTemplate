package cn.highedu.nnshop.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author kakapreter
 * @since 2023-09-13
 */
@RestController
@RequestMapping("/invetoryrecord")
public class InvetoryrecordController {

}

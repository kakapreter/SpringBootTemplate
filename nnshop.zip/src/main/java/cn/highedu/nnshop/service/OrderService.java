package cn.highedu.nnshop.service;

import cn.highedu.nnshop.entity.Order;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author kakapreter
 * @since 2023-09-13
 */
public interface OrderService extends IService<Order> {

}
